These assets have been created a while ago already, before any page demonstrations were. I had forgotten to upload them to GitHub.

Some insights regarding the brand's identity:

One thing a lot of geek stores lack is personality. They're mostly bland and squared, which contradicts what you'd expect from a store that sells to people with interests that stand out from the norm. We should make sure our store has some personality, adding an element to it that almost all geeks know, Pokémon. Pikachu and the starter 3 are pretty overused, and we want to transmit a friendly, relaxed vibe to our customers, so running with a goofy, blue pokemon like Quagsire seemed ideal. 

The Shiny variation of a Pokémon is a rare find, where the Pokémon presentes itself with a different colour from the usual. In Quagsire's case, the shiny variation is pink (#f28af7). We're gonna use this palette for sales and new products. When you think New and Novidades, you think of something starry, bright and *shiny*. The joke makes itself, and it will be something the knowledgeable fans will appreciate, while not disrupting from the colour scheme too much for normal users.

The logo is a Pokeball rebranded with Quagsire's colour palette, with his wide, small eyes added. 